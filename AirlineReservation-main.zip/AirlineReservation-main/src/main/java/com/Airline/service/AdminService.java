package com.Airline.service;

import com.Airline.entity.Admin;

public interface AdminService {
	public void registerAdmin(Admin admin);

	Admin loginAdmin(String email, String password);
	
}