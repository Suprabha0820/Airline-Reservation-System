package com.Airline.entity;

public enum BookingStatus {
	CONFIRMED, CANCELLED, FLIGHTCANCELLED

}
