package com.Airline.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Booking {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long bookingId;
	@ManyToOne
	@JoinColumn(name = "user_id")
	@JsonBackReference
	private User user;
	@ManyToOne
	@JoinColumn(name = "flight_id")
	@JsonBackReference
	private Flight flight;
	private int fromSeatNo;
	private int toSeatNo;
	private int noOfSeat;

	private String passanger2;
	private String passanger3;
	private String passanger4;
	
	@Column(unique = true)
	private String pnr;

	@Enumerated(EnumType.STRING)
	private BookingStatus bookingStatus = BookingStatus.CONFIRMED;

	public Long getBookingId() {
		return bookingId;
	}

	public void setBookingId(Long bookingId) {
		this.bookingId = bookingId;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Flight getFlight() {
		return flight;
	}

	public void setFlight(Flight flight) {
		this.flight = flight;
	}

	public int getFromSeatNo() {
		return fromSeatNo;
	}

	public void setFromSeatNo(int fromSeatNo) {
		this.fromSeatNo = fromSeatNo;
	}

	public int getToSeatNo() {
		return toSeatNo;
	}

	public void setToSeatNo(int toSeatNo) {
		this.toSeatNo = toSeatNo;
	}

	public int getNoOfSeat() {
		return noOfSeat;
	}

	public void setNoOfSeat(int noOfSeat) {
		this.noOfSeat = noOfSeat;
	}

	public String getPassanger2() {
		return passanger2;
	}

	public void setPassanger2(String passanger2) {
		this.passanger2 = passanger2;
	}

	public String getPassanger3() {
		return passanger3;
	}

	public void setPassanger3(String passanger3) {
		this.passanger3 = passanger3;
	}

	public String getPassanger4() {
		return passanger4;
	}

	public void setPassanger4(String passanger4) {
		this.passanger4 = passanger4;
	}

	public String getPnr() {
		return pnr;
	}

	public void setPnr(String pnr) {
		this.pnr = pnr;
	}

	public BookingStatus getBookingStatus() {
		return bookingStatus;
	}

	public void setBookingStatus(BookingStatus bookingStatus) {
		this.bookingStatus = bookingStatus;
	}

	public Booking() {
		super();
		this.bookingId = bookingId;
		this.user = user;
		this.flight = flight;
		this.fromSeatNo = fromSeatNo;
		this.toSeatNo = toSeatNo;
		this.noOfSeat = noOfSeat;
		this.passanger2 = passanger2;
		this.passanger3 = passanger3;
		this.passanger4 = passanger4;
		this.pnr = pnr;
		this.bookingStatus = bookingStatus;
	}
	

}