package com.Airline.entity;

public enum FlightStatus {
	 
	 SCHEDULED, CANCELLED
}

